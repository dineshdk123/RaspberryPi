import paho.mqtt.client as mqtt
import json

THINGSBOARD_TOKEN = "   Yk99TPN0vyQumrHxxzyw"

client = mqtt.Client()
client.username_pw_set(THINGSBOARD_TOKEN)
client.connect("mqtt.thingsboard.cloud", 1883, 60)
client.loop_start()

payload = {
    "plate": "TEST1234",
    "timestamp": "2025-06-16 18:10:00",
    "confidence": 0.95
}

client.publish("v1/devices/me/telemetry", json.dumps(payload))
client.loop_stop()
client.disconnect()
