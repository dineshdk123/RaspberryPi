import cv2
import base64
import json
from datetime import datetime
from ocr_utils import extract_plate_text
from mqtt_client import publish_plate  # ← Your local MQTT function
import easyocr
import warnings
import paho.mqtt.client as mqtt  # For ThingsBoard cloud
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

warnings.filterwarnings("ignore", category=UserWarning)
reader = easyocr.Reader(['en'], gpu=False)

# 🌐 Your ThingsBoard device token
THINGSBOARD_TOKEN = "Yk99TPN0vyQumrHxxzyw"
THINGSBOARD_BROKER = "mqtt.thingsboard.cloud"
THINGSBOARD_PORT = 1883
THINGSBOARD_TOPIC = "v1/devices/me/telemetry"

# 🧠 Function to send data to ThingsBoard Cloud
def publish_to_thingsboard(plate, timestamp, confidence):
    try:
        client = mqtt.Client()
        client.username_pw_set(THINGSBOARD_TOKEN)
        client.connect(THINGSBOARD_BROKER, THINGSBOARD_PORT, 60)
        client.loop_start()

        payload = {
            "plate": plate,
            "timestamp": timestamp,
            "confidence": round(confidence, 2)
        }

        result = client.publish(THINGSBOARD_TOPIC, json.dumps(payload))
        result.wait_for_publish()

        client.loop_stop()
        client.disconnect()

        print(f"📤 [ThingsBoard] Published plate: {plate}")

    except Exception as e:
        print(f"❌ [ThingsBoard] MQTT Error: {e}")

# 🖼️ Encode image to base64
def encode_image(image):
    _, buffer = cv2.imencode('.jpg', image)
    return base64.b64encode(buffer).decode('utf-8')

# 🎯 Main Detection Flow
def test_image_detection(image_path):
    print(f"📂 Loading image: {image_path}")
    frame = cv2.imread(image_path)
    if frame is None:
        print("❌ Could not load image.")
        return

    print(f"📏 Original image size: {frame.shape}")
    print("🧠 Running OCR on full image...")

    # Run EasyOCR directly on full image
    raw_results = reader.readtext(frame)
    print("\n🔍 Raw OCR Detected Texts:")
    for _, text, conf in raw_results:
        print(f"- '{text}' (Confidence: {conf:.2f})")

    # Clean filtered results
    plates = extract_plate_text(frame)

    if not plates:
        print("⚠️ No valid plate detected.")
        return

    # Encode image for local MQTT
    image_data = encode_image(frame)

    for text, conf in plates:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"✅ Detected Plate: {text} - {conf:.2f}")

        # 🔁 Publish to local MQTT
        publish_plate(text, timestamp, conf, image_data)

        # ☁️ Publish to ThingsBoard
        publish_to_thingsboard(text, timestamp, conf)

if __name__ == "__main__":
    test_image_detection("test_plate.jpg")  # Replace with your image path
