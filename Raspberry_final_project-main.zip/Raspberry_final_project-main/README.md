# Raspberry_final_project
Smart License Plate Project
This project automatically detects vehicle license plates from images using OCR and sends the results to:
A local MQTT broker (e.g., Raspberry Pi)
A cloud dashboard via ThingsBoard

It supports image input or camera, and displays results in a clean dashboard.

Features:

OCR-based license plate detection (using EasyOCR)
Sends data to both local MQTT and ThingsBoard Cloud
Local Raspberry Pi dashboard (SQLite + Flask/Tkinter)
Cloud dashboard with plate number, confidence, timestamp, and image preview
Example Output:

📂 Loading image: test_plate.jpg
🧠 Running OCR...
✅ Detected Plate: KA51MK4666 (Confidence: 1.00)
📤 Published to ThingsBoard and MQTT Broker


In this project : 

Deliverables given by the participants

Abhijit -264157	    OCR Detection
Saurabh - U78664	  Laptop (MQTT-Publisher) to Raspberrypi (MQTT -Subscriber)
Dinesh - 265278	    DB,Squilitte,logs,Thingsboard dashboard-access token 
Nimra - 258882	    Viewer APP,tkinter,Flask



