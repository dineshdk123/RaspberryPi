import socket
import json
import urllib.request

API_KEY = "ae711dada6d74cd49501fbdc95301a38"  # Replace with your actual OpenWeatherMap API key
PI_IP = "192.168.43.153"    # Replace with your Raspberry Pi’s IP address
PI_PORT = 12345

def get_weather(city):
    """Fetch weather data from OpenWeatherMap API for the given city."""
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    with urllib.request.urlopen(url) as response:
        data = json.loads(response.read().decode())
        return {
            "temp": data["main"]["temp"],
            "pressure": data["main"]["pressure"],
            "condition": data["weather"][0]["main"]
        }

def send_to_pi(data):
    """Send the weather data to the Raspberry Pi server."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((PI_IP, PI_PORT))
        s.send(json.dumps(data).encode())
#print("Sending data:", data)

if __name__ == "__main__":
    # Prompt the user for the city name
    city = input("Enter the city name: ").strip()
    
    if city:
        weather = get_weather(city)
        print(f"Sending weather data for {city}: {weather}")
        send_to_pi(weather)
    else:
        print("City name cannot be empty. Please provide a valid city name.")
